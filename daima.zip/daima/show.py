import open3d as o3d
import numpy as np

def align_to_ground(pcd, distance_threshold=0.2, ransac_n=3, num_iterations=1000):
    """ 使用Open3D内置RANSAC平面检测实现地面对齐
    Args:
        pcd: open3d点云对象
        distance_threshold: 平面内点阈值（米）
        ransac_n: 每次采样点数
        num_iterations: RANSAC迭代次数
    Returns:
        变换后的点云
        变换矩阵 (4x4)
    """
    # 预处理：移除无效点
    pts = np.asarray(pcd.points)
    valid_mask = ~np.isnan(pts).any(axis=1)
    pcd_filtered = pcd.select_by_index(np.where(valid_mask)[0])

    # 检测主平面（地面）
    plane_model, inliers = pcd_filtered.segment_plane(
        distance_threshold=distance_threshold,
        ransac_n=ransac_n,
        num_iterations=num_iterations
    )
    
    # 提取平面参数 [a,b,c,d] => ax + by + cz + d = 0
    a, b, c, d = plane_model
    normal = np.array([a, b, c])
    normal /= np.linalg.norm(normal)  # 单位化法向量
    
    # 构建将法线对齐到Z轴的变换
    z_axis = np.array([0, 0, 1])
    rotation = rotation_matrix_from_vectors(normal, z_axis)
    
    # 计算平移量：使地面平面经过原点
    centroid = np.mean(np.asarray(pcd_filtered.select_by_index(inliers).points), axis=0)
    translation = -rotation @ centroid
    
    # 合成变换矩阵
    T = np.eye(4)
    T[:3, :3] = rotation
    T[:3, 3] = translation
    
    # 应用变换
    transformed_pcd = pcd.transform(T)
    
    return pcd, T

def rotation_matrix_from_vectors(a, b):
    """ 计算旋转矩阵 (优化版) """
    a = a / np.linalg.norm(a)
    b = b / np.linalg.norm(b)
    
    if np.allclose(a, b):
        return np.eye(3)
    if np.allclose(a, -b):
        return -np.eye(3)
    
    # 计算旋转轴和角度
    v = np.cross(a, b)
    c = np.dot(a, b)
    angle = np.arccos(c)
    
    # Rodrigues' rotation formula
    K = np.array([[0, -v[2], v[1]],
                  [v[2], 0, -v[0]],
                  [-v[1], v[0], 0]])
    R = np.eye(3) + np.sin(angle)*K + (1-np.cos(angle))*(K@K)
    return R

# 使用示例
if __name__ == "__main__":
    # 1. 加载点云

    pcd = o3d.io.read_point_cloud("./output/point.ply")

    # # 2. 执行地面对齐
    # aligned_pcd, T = align_to_ground(pcd, distance_threshold=0.2)
    
    # 3. 可视化对比

    render_option = o3d.visualization.RenderOption()
    render_option.point_size = 6.0  # 默认1.0，增大此值使点膨胀
    o3d.visualization.draw_geometries(
        [pcd], 
        window_name="Original Cloud",
        width=1000,
        height=728
    )
    
    # o3d.visualization.draw_geometries(
    #     [aligned_pcd, aligned_frame], 
    #     window_name="Aligned Cloud",
    #     width=1024,
    #     height=768
    # )
