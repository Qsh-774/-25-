import os
import numpy as np
import open3d as o3d
from PIL import Image
from math import cos, sin, radians

# 完全禁用所有GPU相关功能
os.environ['OPEN3D_CPU_RENDERING'] = '1'
os.environ['LIBGL_ALWAYS_SOFTWARE'] = '1'
os.environ['DISPLAY'] = ':0'

def render_pcd_to_image(pcd, output_path, resolution=(800, 600), rotation_angle=0, scale_factor=0.8, point_size=6):
    """
    完全基于CPU的点云渲染替代方案
    使用numpy和PIL进行简单2D投影渲染
    
    参数:
        pcd: 点云对象
        output_path: 输出图像路径
        resolution: 图像分辨率 (宽, 高)
        rotation_angle: 绕Z轴旋转角度(度)
        scale_factor: 缩放因子 (0-1), 控制点云在图像中的大小 (默认0.8)
        point_size: 点的大小 (像素，默认6)
    """
    try:
        # 获取点云数据
        points = np.asarray(pcd.points)
        colors = np.asarray(pcd.colors) if pcd.has_colors() else np.array([[0.7, 0.7, 0.7]] * len(points))
        
        # 计算点云的几何中心
        center = np.mean(points, axis=0)
        
        # 将点云中心移动到原点
        centered_points = points - center
        
        # 应用绕Z轴旋转
        if rotation_angle != 0:
            angle_rad = radians(rotation_angle)
            # 旋转矩阵 (绕Z轴旋转)
            rotation_matrix = np.array([
                [cos(angle_rad), -sin(angle_rad), 0],
                [sin(angle_rad), cos(angle_rad), 0],
                [0, 0, 1]
            ])
            centered_points = np.dot(centered_points, rotation_matrix)
        
        # 简单正交投影 (使用XY平面)
        xy = centered_points[:, :2]  # 只使用XY坐标
        
        # 计算点云边界
        min_xy = np.min(xy, axis=0)
        max_xy = np.max(xy, axis=0)
        size = max_xy - min_xy
        
        # 归一化坐标到图像空间 (居中并缩放)
        # 使用最大尺寸进行归一化，保持纵横比
        max_size = max(size[0], size[1])
        if max_size > 0:
            xy = xy / max_size  # 归一化到[-1,1]区间
        
        # 应用缩放因子 - 增大到0.8使点云在图像中占据更大比例
        xy *= scale_factor * np.min(resolution)
        
        # 将坐标转换到图像中心
        xy += np.array([resolution[0]/2, resolution[1]/2])
        
        # 创建空白图像
        image = np.zeros((resolution[1], resolution[0], 3), dtype=np.uint8)
        image.fill(0)  # 黑色背景
        
        # 绘制点云 (支持点大小)
        for i in range(len(centered_points)):
            x, y = int(xy[i, 0]), int(resolution[1]-1 - xy[i, 1])
            color = (colors[i] * 255).astype(np.uint8) if pcd.has_colors() else np.array([100, 100, 100])
            
            # 绘制点 (支持大小)
            if point_size <= 1:
                # 单像素点
                if 0 <= x < resolution[0] and 0 <= y < resolution[1]:
                    image[y, x] = color
            else:
                # 多像素点
                half_size = point_size // 2
                for dx in range(-half_size, half_size + 1):
                    for dy in range(-half_size, half_size + 1):
                        px = x + dx
                        py = y + dy
                        if 0 <= px < resolution[0] and 0 <= py < resolution[1]:
                            image[py, px] = color
        
        # 保存图像
        Image.fromarray(image).save(output_path)
        return True
        
    except Exception as e:
        print(f"渲染错误: {str(e)}")
        return False

def process_pcd(input_file, output_folder, num_views=36):
    """处理点云文件并生成多个视角"""
    try:
        # 读取点云
        pcd = o3d.io.read_point_cloud(input_file)
        if not pcd.has_points():
            raise ValueError("点云文件为空")
        
        # 准备输出路径 - 先清空文件夹但保留文件夹本身
        os.makedirs(output_folder, exist_ok=True)  # 确保文件夹存在
        # 清空文件夹中的所有文件
        for filename in os.listdir(output_folder):
            file_path = os.path.join(output_folder, filename)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
            except Exception as e:
                print(f"无法删除文件 {file_path}: {e}")
        
        base_name = os.path.splitext(os.path.basename(input_file))[0]
        
        # 生成多个视角 (每10度一个)
        for i in range(num_views):
            angle = i * (360 / num_views)  # 均匀分布的角度
            output_path = os.path.join(output_folder, f"{base_name}_view_{i:03d}_{int(angle)}deg.png")
            
            # 渲染点云 (使用0.8的缩放因子和6像素的点大小)
            if not render_pcd_to_image(pcd, output_path, rotation_angle=angle, scale_factor=0.8, point_size=6):
                # 简化点云后重试
                pcd_simplified = pcd.voxel_down_sample(voxel_size=0.05)
                if render_pcd_to_image(pcd_simplified, output_path, rotation_angle=angle, scale_factor=0.8, point_size=6):
                    print(f"使用简化点云成功保存到: {output_path}")
                else:
                    print(f"视角 {i} 渲染失败")
            else:
                print(f"成功保存到: {output_path}")
                
    except Exception as e:
        print(f"处理失败: {str(e)}")

if __name__ == "__main__":
    # 配置输入输出
    input_ply = "./output/point.ply"
    output_dir = "./dianyunt_png_output"
    
    # 执行处理，生成36个视角(每10度一个)
    process_pcd(input_ply, output_dir, num_views=360)