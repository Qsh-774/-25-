import os
import time
from flask import Flask, render_template, request, redirect, url_for
import cv2
import numpy as np

# 配置路径
UPLOAD_FOLDER = 'static/uploads'
ORIGINALS_FOLDER = 'originals'
IMAGES_FOLDER = 'images'
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['ORIGINALS_FOLDER'] = ORIGINALS_FOLDER
app.config['IMAGES_FOLDER'] = IMAGES_FOLDER

# 创建文件夹
for folder in [UPLOAD_FOLDER, ORIGINALS_FOLDER, IMAGES_FOLDER]:
    os.makedirs(folder, exist_ok=True)

@app.route('/')
def index():
    """主页面路由"""
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_video():
    """处理视频上传路由"""
    if 'video' not in request.files:
        return redirect(url_for('index'))
    
    video_file = request.files['video']
    if video_file.filename == '':
        return redirect(url_for('index'))
    
    if video_file:
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        timestamp = int(time.time())
        filename = f"{timestamp}_{video_file.filename}"
        video_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        video_file.save(video_path)
        
        start_time = time.time()
        result = process_video(video_path)
        processing_time = time.time() - start_time
        
        saved_originals = len(os.listdir(ORIGINALS_FOLDER))
        saved_processed = len(os.listdir(IMAGES_FOLDER))
        
        return render_template(
            'result.html',
            video_name=video_file.filename,
            total_frames=result['total_frames'],
            keyframe_count=result['keyframe_count'],
            fps=result['fps'],
            resolution=result['resolution'],
            processing_time=f"{processing_time:.2f}",
            saved_originals=saved_originals,
            saved_processed=saved_processed
        )
    
    return redirect(url_for('index'))

def process_video(video_path):
    """处理视频并提取关键帧（不超过80张）"""
    clear_folder(ORIGINALS_FOLDER)
    clear_folder(IMAGES_FOLDER)
    
    cap = cv2.VideoCapture(video_path)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    # 计算关键帧间隔（限制在80帧以内）
    frame_interval = max(1, total_frames // 80)
    print(f"视频信息: {frame_width}x{frame_height}, FPS: {fps:.1f}, 总帧数: {total_frames}")
    print(f"关键帧间隔: {frame_interval}帧 (预计提取 {min(80, total_frames//frame_interval)} 个关键帧)")
    
    keyframe_count = 0
    processed_count = 0
    
    for frame_idx in range(total_frames):
        ret, frame = cap.read()
        if not ret:
            break
            
        if frame_idx % frame_interval == 0:
            orig_filename = os.path.join(ORIGINALS_FOLDER, f"original_{frame_idx:05d}.png")
            cv2.imwrite(orig_filename, frame)
            
            optimized_frame = optimize_for_pointcloud(frame)
            processed_filename = os.path.join(IMAGES_FOLDER, f"processed_{processed_count:05d}.png")
            cv2.imwrite(processed_filename, optimized_frame)
            
            keyframe_count += 1
            processed_count += 1
            
            # 确保不超过80帧
            if keyframe_count >= 80:
                print(f"已达到80帧上限，停止提取")
                break
    
    cap.release()
    print(f"成功提取 {keyframe_count} 个关键帧")
    
    return {
        'total_frames': total_frames,
        'keyframe_count': keyframe_count,
        'fps': fps,
        'resolution': (frame_width, frame_height)
    }

def optimize_for_pointcloud(frame):
    """为点云提取优化的图像处理"""
    return frame

def clear_folder(folder_path):
    """清空文件夹内容"""
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
        except Exception as e:
            print(f"删除文件出错: {file_path} - {e}")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)