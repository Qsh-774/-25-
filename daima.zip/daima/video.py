import os
import cv2
import quadrant_mirror
import dianyun4
try:
    from natsort import natsorted
    HAVE_NATSORT = True
except ImportError:
    HAVE_NATSORT = False
    print("注意: natsort 模块未安装，将使用普通排序方法")

def png_to_video(input_folder, output_video=None, fps=2, img_duration=0.5):
    """
    将文件夹中的 PNG 图片转换为视频
    
    参数:
        input_folder: 包含 PNG 图片的文件夹路径
        output_video: 输出视频文件路径（可选，如不指定则自动生成）
        fps: 视频帧率 (默认1帧/秒)
        img_duration: 每张图片在视频中显示的秒数 (默认1秒)
    """
    # 获取文件夹中所有 PNG 文件
    png_files = [f for f in os.listdir(input_folder) if f.lower().endswith('.png')]
    
    # 使用排序方法
    if HAVE_NATSORT:
        png_files = natsorted(png_files)
    else:
        png_files = sorted(png_files)
        print("注意: 使用普通排序方法，文件名排序可能不如自然排序准确")
    
    if not png_files:
        print("错误: 指定的文件夹中没有 PNG 文件")
        return
    
    # 读取第一张图片获取尺寸信息
    first_image = cv2.imread(os.path.join(input_folder, png_files[0]))
    if first_image is None:
        print(f"错误: 无法读取图片 {png_files[0]}")
        return
    height, width, layers = first_image.shape
    
    # 如果未指定输出视频路径，则自动生成在与输入文件夹并行的位置
    if output_video is None:
        parent_dir = os.path.dirname(input_folder)
        folder_name = os.path.basename(input_folder)
        output_video = os.path.join(parent_dir, f"{folder_name}_video.mp4")
    
    # 创建视频写入对象
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    video = cv2.VideoWriter(output_video, fourcc, fps, (width, height))
    
    if not video.isOpened():
        print(f"错误: 无法创建视频文件 {output_video}")
        return
    
    print(f"开始创建视频，共 {len(png_files)} 张图片...")
    print(f"输入文件夹: {input_folder}")
    print(f"输出视频: {output_video}")
    
    for png_file in png_files:
        img_path = os.path.join(input_folder, png_file)
        img = cv2.imread(img_path)
        
        if img is None:
            print(f"警告: 无法读取图片 {png_file}，跳过")
            continue
        
        # 每张图片写入 img_duration * fps 帧
        for _ in range(int(fps * img_duration)):
            video.write(img)
        
        print(f"已处理: {png_file}")
    
    video.release()
    print(f"视频创建完成，已保存到: {output_video}")

if __name__ == "__main__":
    # os.system("")
    # os.system("colmap automatic_reconstructor --workspace_path ./output --image_path ./images ") 
    # os.system("colmap model_converter --input_path ./output/sparse/0 --output_path ./output/point.ply --output_type PLY") 
    #dianyun4
    # 配置输入输出
    input_ply = "./output/point.ply"
    output_dir = "./dianyunt_png_output"
    
    # 执行处理，生成72个视角(每5度一个)
    dianyun4.process_pcd(input_ply, output_dir, num_views=360)


    #quadrant_mirror
    # 指定输入文件夹路径
    input_dir = "/home/elf/colmap/dianyunt_png_output"
    

    # 执行批量处理
    print("开始批量处理图片...")
    result_files = quadrant_mirror.batch_process_jellyfish(input_dir)
    print(f"\n处理完成！共生成 {len(result_files)} 个九宫格图片:")
    for file in result_files:
        print(f"- {file}")
    #------------------------------


    # 输入参数
    input_folder = "/home/elf/colmap/dianyunt_png_output_grid_output"
    
    # 调用函数
    png_to_video(input_folder, fps=4, img_duration=0.25)