import os
import cv2
import numpy as np

def create_rotated_jellyfish_grid(input_path, output_folder=None):
    """
    创建九宫格布局，将水母图片旋转后放入指定格子
    参数：
        input_path: 输入水母图片路径
        output_folder: 输出文件夹路径（None时自动创建同级目录）
    """
    # 1. 读取图片并确保透明通道
    jelly = cv2.imread(input_path, cv2.IMREAD_UNCHANGED)
    if jelly is None:
        raise FileNotFoundError(f"无法读取图片: {input_path}")
    
    if jelly.shape[2] == 3:  # 无透明通道
        jelly = cv2.cvtColor(jelly, cv2.COLOR_BGR2BGRA)
    
    # 2. 创建3倍大小的黑色背景
    h, w = jelly.shape[:2]
    canvas = np.zeros((h*3, w*3, 4), dtype=np.uint8)
    
    # 3. 定义旋转和位置映射
    rotations = {
        2: 0,    # 第二格：原图
        6: 90,   # 第六格：顺时针90度
        8: 180,  # 第八格：180度
        4: 270   # 第四格：逆时针90度
    }
    
    # 4. 计算九宫格坐标
    def get_position(cell_num):
        """获取格子中心坐标"""
        row = (cell_num - 1) // 3
        col = (cell_num - 1) % 3
        return (row * h, col * w)
    
    # 5. 处理每个旋转版本
    for cell_num, angle in rotations.items():
        # 旋转图片（保持透明通道）
        rows, cols = jelly.shape[:2]
        M = cv2.getRotationMatrix2D((cols/2, rows/2), angle, 1)
        rotated = cv2.warpAffine(jelly, M, (cols, rows), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_TRANSPARENT)
        
        # 获取放置位置
        y, x = get_position(cell_num)
        
        # 叠加到画布（允许重叠）
        canvas[y:y+h, x:x+w] = cv2.add(canvas[y:y+h, x:x+w], rotated)
    
    # 6. 增强蓝色调（匹配第一张图效果）
    canvas[:, :, 0] = np.clip(canvas[:, :, 0] * 1.2, 0, 255)  # 蓝色通道
    
    # 7. 自动生成输出路径（与输入文件夹同级）
    if output_folder is None:
        input_dir = os.path.dirname(input_path)
        parent_dir = os.path.dirname(input_dir)
        output_dir_name = os.path.basename(input_dir) + "_grid_output"
        output_folder = os.path.join(parent_dir, output_dir_name)
    
    # 确保输出文件夹存在
    os.makedirs(output_folder, exist_ok=True)
    
    # 8. 生成输出文件名（保持原文件名）
    filename = os.path.basename(input_path)
    output_filename = os.path.splitext(filename)[0] + "_grid.png"
    output_path = os.path.join(output_folder, output_filename)
    
    # 9. 保存结果
    cv2.imwrite(output_path, canvas)
    return output_path

def batch_process_jellyfish(input_folder):
    """
    批量处理文件夹中的所有JPG文件
    参数：
        input_folder: 输入文件夹路径
    """
    # 确保输入文件夹存在
    if not os.path.exists(input_folder):
        raise FileNotFoundError(f"输入文件夹不存在: {input_folder}")
    
    # 遍历文件夹中的所有png文件
    processed_files = []
    for filename in os.listdir(input_folder):
        if filename.lower().endswith('.png'):
            try:
                input_path = os.path.join(input_folder, filename)
                output_path = create_rotated_jellyfish_grid(input_path)
                processed_files.append(output_path)
                print(f"已处理: {filename} -> {os.path.relpath(output_path)}")
            except Exception as e:
                print(f"处理失败 {filename}: {str(e)}")
    
    return processed_files

if __name__ == "__main__":

    # 指定输入文件夹路径
    input_dir = "/home/elf/colmap/dianyunt_png_output"
    
    # 执行批量处理
    print("开始批量处理图片...")
    result_files = batch_process_jellyfish(input_dir)
    print(f"\n处理完成！共生成 {len(result_files)} 个九宫格图片:")
    for file in result_files:
        print(f"- {file}")