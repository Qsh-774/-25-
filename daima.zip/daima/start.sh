#!/bin/bash

# 增强版错误处理函数
show_error() {
    local error_line=$1
    local error_command=$2
    zenity --error --text="脚本执行出错！\n\n出错位置: 第 ${error_line} 行\n执行命令: ${error_command}\n错误详情: $3" \
           --title="错误报告" --width=400
    exit 1
}

# 使用 trap 捕获 ERR 信号
trap 'show_error ${LINENO} "${BASH_COMMAND}" "$_"' ERR

# 定义函数显示选择对话框
show_selection_dialog() {
    while true; do
        choice=$(zenity --list --title="选择操作" --text="请选择要执行的操作:" \
                        --column="选项" \
                        "播放全息投影视频" \
                        "显示3D点云图" \
                        "退出" \
                        --height=200 --width=300) || {
            echo "用户取消了对话框"
            exit 0
        }
        
        case "$choice" in
            "播放全息投影视频")
                echo "正在播放全息投影视频..."
                if [ ! -f "dianyunt_png_output_grid_output_video.mp4" ]; then
                    show_error ${LINENO} "视频文件检查" "视频文件不存在: dianyunt_png_output_grid_output_video.mp4"
                fi
                xdg-open "dianyunt_png_output_grid_output_video.mp4"
                # 等待视频播放器关闭
                while pgrep -f "dianyunt_png_output_grid_output_video.mp4" > /dev/null; do
                    sleep 1
                done
                ;;
                
            "显示3D点云图")
                echo "正在显示3D点云图..."
                local pointcloud_file="/home/elf/colmap/output/point.ply"
                if [ ! -f "$pointcloud_file" ]; then
                    show_error ${LINENO} "点云文件检查" "点云文件不存在: ${pointcloud_file}"
                fi
                if ! command -v python3 &> /dev/null; then
                    show_error ${LINENO} "Python检查" "Python3 未安装"
                fi
                python3 "/home/elf/colmap/show.py" "$pointcloud_file"
                # 等待点云查看器关闭
                while pgrep -f "show.py" > /dev/null; do
                    sleep 1
                done
                ;;
                
            "退出"|"")
                echo "操作已取消"
                exit 0
                ;;
                
            *)
                show_error ${LINENO} "选项处理" "未知选项: $choice"
                ;;
        esac
    done
}

# 主脚本开始（添加详细日志）
echo "==== 开始执行全息投影处理流程 ===="
echo "当前目录: $(pwd)"
echo "当前用户: $(whoami)"
echo "执行时间: $(date)"

# 清理并重建（添加步骤确认）
echo "[1/4] 清理输出目录..."
if [ ! -d "/home/elf/colmap/output" ]; then
    show_error ${LINENO} "目录检查" "输出目录不存在: /home/elf/colmap/output"
fi
rm -rf /home/elf/colmap/output/* || {
    show_error ${LINENO} "清理输出目录" "无法清理输出目录"
}

echo "[2/4] 进入colmap目录..."
cd /home/elf/colmap || {
    show_error ${LINENO} "切换目录" "无法进入目录: /home/elf/colmap"
}

# 运行 COLMAP 自动重建（添加前置检查）
echo "[3/4] 运行COLMAP自动重建..."
if [ ! -d "./images" ]; then
    show_error ${LINENO} "图像目录检查" "图像目录不存在: ./images"
fi
if ! command -v colmap &> /dev/null; then
    show_error ${LINENO} "COLMAP检查" "COLMAP 未安装"
fi
colmap automatic_reconstructor \
    --workspace_path ./output \
    --image_path ./images || {
    show_error ${LINENO} "COLMAP重建" "3D重建过程失败"
}

# 转换模型为 PLY 格式（添加结果验证）
echo "[4/4] 转换模型为PLY格式..."
colmap model_converter \
    --input_path ./output/sparse/0 \
    --output_path ./output/point.ply \
    --output_type PLY || {
    show_error ${LINENO} "模型转换" "PLY文件生成失败"
}

if [ ! -f "./output/point.ply" ]; then
    show_error ${LINENO} "输出验证" "生成的PLY文件不存在"
fi

# 生成全息投影视频（添加验证）
echo "[5/5] 生成全息投影视频..."
if [ ! -f "video.py" ]; then
    show_error ${LINENO} "脚本检查" "视频生成脚本不存在: video.py"
fi
python3 video.py || {
    show_error ${LINENO} "视频生成" "视频生成过程失败"
}

if [ ! -f "dianyunt_png_output_grid_output_video.mp4" ]; then
    show_error ${LINENO} "输出验证" "生成的视频文件不存在"
fi

# 显示选择对话框
echo "处理完成，显示选项菜单..."
show_selection_dialog

echo "所有步骤执行完成！"